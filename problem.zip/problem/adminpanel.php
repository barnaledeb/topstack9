<?php include('bobi/menu.php'); ?>

     <!--main content section starts--> 

     <div class="main-content">
       <div class="wrapper">
          <!-- <strong>DASHBOARD</strong> -->
            <h1>DASHBOARD</h1>
          <div class="col-4 text-center">
          <h1>5</h1>
          <br>
          categories

          </div>
          <div class="col-4 text-center">
          <h1>5</h1>
          <br>
          categories

          </div>
          <div class="col-4 text-center">
          <h1>5</h1>
          <br>
          categories

          </div>
          <div class="col-4 text-center">
          <h1>5</h1>
          <br>
          categories

          </div>
          
          <div class="clearfix"></div>
         </div>
     </div>
     <!--main content section ends--> 
<?php include('bobi/footer.php'); ?>