<?php include "constants.php"; ?>
<html>
    <head>
        <title>Food order website home page</title>
        <link rel="stylesheet" href="all.css">
    </head>
    <body>
        <!-- <h1>admin Panel</h1> -->
        <!--menu section starts-->
        <div class="menu text-center">
            <div class="wrapper">
                <ul>
                    <li><a href="adminpanel.php">Home</a></li>
                    <li><a href="manage-user.php">User</a></li>
                    <li><a href="manage-category.php">Category</a></li>
                    <li><a href="manage-food.php">Food</a></li>
                    <li><a href="manage-order.php">order</a></li>
                </ul>
            </div>
        </div>
     <!--menu section endss--> 
    </body>
</html>