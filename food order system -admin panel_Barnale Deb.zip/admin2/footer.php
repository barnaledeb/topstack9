<!doctype html>
<html>
  <head>
    <title>Admin Page</title>
    <link rel="stylesheet" href="admin.css">
  </head>
  <body>
    <!--footer section starts--> 
    <div class="footer">
      <div class="wrapper">
        <p class="text-center">2022 All rights reserved,Thirsty restrurent.Developed by- <a href="#">Barnale Deb</a></p>
      </div>
    </div>
    <!--footer section ends--> 
  </body>
</html>